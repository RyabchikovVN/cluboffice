# PWA-example

https://maddevs.io/blog/progressive-web-apps-practical-usage-guide
